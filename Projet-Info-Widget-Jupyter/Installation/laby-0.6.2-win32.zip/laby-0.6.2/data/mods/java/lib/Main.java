public class Main {

  public static void main(String[] args) {
      laby_name_Ant f = new laby_name_Ant();
      f.laby_name_ant();
  }

}